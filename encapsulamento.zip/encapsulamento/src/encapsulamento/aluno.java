
package encapsulamento;


public class aluno {
     private String nome;
     public String endereco;

public aluno (String nome, String endereco){
           
          this.nome = nome;
          this.endereco = endereco;
     }
     
     public String getnome(){

         return (this.nome);

     }
     
     public void setnome (String nome){
         
         this.nome = nome;
         
     }
}




     
    


    
    
       
    
    

