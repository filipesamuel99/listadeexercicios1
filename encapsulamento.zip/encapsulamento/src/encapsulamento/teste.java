
package encapsulamento;


public class teste {
     public static void main (String[]args){

          aluno a1 = new aluno ("João", "Rua do ouro");
          /*system.out.println (a1.nome); a1.nome não pode ser executado devido ao atributo nome ser private*/
	  System.out.println (a1.getnome());
          
          a1.setnome ("Maria");
          System.out.println(a1.getnome());
     }
}
